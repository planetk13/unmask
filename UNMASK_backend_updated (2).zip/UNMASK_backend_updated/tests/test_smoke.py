import os
os.environ.setdefault("FLASK_ENV", "development")
os.environ.setdefault("SECRET_KEY", "test-only-secret-key-please-change")
os.environ.setdefault("SESSION_COOKIE_SECURE", "false")
os.environ.setdefault("CORS_ORIGINS", "http://localhost:5173")

from app import app

def test_health():
    client = app.test_client()
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.get_json()["status"] == "success"

def test_me_requires_login():
    client = app.test_client()
    response = client.get("/api/me")
    assert response.status_code == 401

def test_csrf_endpoint():
    client = app.test_client()
    response = client.get("/api/csrf-token")
    assert response.status_code == 200
    assert "csrf_token" in response.get_json()
