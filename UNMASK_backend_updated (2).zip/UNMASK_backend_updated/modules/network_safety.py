import ipaddress
import socket

def is_public_address(value):
    try:
        ip = ipaddress.ip_address(value)
        return ip.is_global and not (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast)
    except ValueError:
        return False

def resolve_public_addresses(host):
    try:
        rows = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
        addresses = sorted({row[4][0] for row in rows})
        if not addresses or not all(is_public_address(item) for item in addresses):
            return []
        return addresses
    except OSError:
        return []
