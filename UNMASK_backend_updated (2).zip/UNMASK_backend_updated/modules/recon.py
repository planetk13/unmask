"""Passive, low-impact reconnaissance for a DNS-verified target."""
import socket
import ssl
from datetime import datetime, timezone
from urllib.parse import urlparse

import dns.resolver
import requests
import whois

from modules.network_safety import resolve_public_addresses, is_public_address

TIMEOUT = 7
UA = "UNMASK-Authorized-Recon/1.0"

def _dns(domain):
    output = {}
    for record in ("A", "AAAA", "MX", "NS", "TXT"):
        try:
            output[record] = [str(x).strip('"') for x in dns.resolver.resolve(domain, record, lifetime=TIMEOUT)]
        except Exception as exc:
            output[record] = {"error": type(exc).__name__}
    return output

def _whois(domain):
    try:
        data = whois.whois(domain)
        return {k: str(v) for k, v in data.items() if v is not None}
    except Exception as exc:
        return {"error": type(exc).__name__}

def _tls(domain):
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=TIMEOUT) as sock:
            with ctx.wrap_socket(sock, server_hostname=domain) as tls:
                cert = tls.getpeercert()
                return {"tls_version": tls.version(), "subject": str(cert.get("subject")),
                        "issuer": str(cert.get("issuer")), "not_after": cert.get("notAfter")}
    except Exception as exc:
        return {"error": type(exc).__name__}

def _http(domain):
    # Resolve and reject non-public destinations before making a request.
    addresses = resolve_public_addresses(domain)
    if not addresses or not all(is_public_address(x) for x in addresses):
        return {"error": "Target did not resolve exclusively to public IP addresses"}
    url = f"https://{domain}/"
    try:
        response = requests.get(url, timeout=TIMEOUT, allow_redirects=False,
                                headers={"User-Agent": UA}, stream=True)
        headers = dict(response.headers)
        status = response.status_code
        response.close()
        security_headers = {
            key: headers.get(key) for key in (
                "Strict-Transport-Security", "Content-Security-Policy",
                "X-Frame-Options", "X-Content-Type-Options",
                "Referrer-Policy", "Permissions-Policy"
            )
        }
        return {"status_code": status, "headers": security_headers,
                "server": headers.get("Server"), "powered_by": headers.get("X-Powered-By")}
    except Exception as exc:
        return {"error": type(exc).__name__}

def _subdomains(domain):
    # Certificate Transparency query is passive; cap returned names.
    try:
        response = requests.get("https://crt.sh/", params={"q": f"%.{domain}", "output": "json"},
                                timeout=10, headers={"User-Agent": UA})
        response.raise_for_status()
        names = set()
        for item in response.json():
            for name in item.get("name_value", "").splitlines():
                name = name.strip().lower().lstrip("*.")
                if name == domain or name.endswith("." + domain):
                    names.add(name)
                if len(names) >= 100:
                    break
        return sorted(names)[:100]
    except Exception as exc:
        return {"error": type(exc).__name__}

def run_recon(domain):
    return {
        "target": domain,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "scope": "Passive checks against a DNS-verified target; no port scanning or exploitation.",
        "dns": _dns(domain),
        "whois": _whois(domain),
        "tls": _tls(domain),
        "http": _http(domain),
        "subdomains": _subdomains(domain)
    }
