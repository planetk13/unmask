import secrets
import dns.resolver

def make_verification_token():
    return "unmask-verification=" + secrets.token_urlsafe(32)

def verify_domain(domain, expected_token):
    try:
        answers = dns.resolver.resolve(domain, "TXT", lifetime=5)
        values = []
        for answer in answers:
            values.append("".join(part.decode() if isinstance(part, bytes) else str(part)
                                  for part in answer.strings))
        if expected_token in values:
            return True, "DNS TXT ownership verified"
        return False, "The expected TXT record was not found"
    except Exception:
        return False, "DNS TXT record could not be resolved. Check the record and try again."
