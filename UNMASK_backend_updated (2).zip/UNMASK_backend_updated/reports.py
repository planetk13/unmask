from html import escape
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet

def make_html_report(domain, results):
    rows = []
    for key, value in results.items():
        rows.append(f"<tr><th>{escape(str(key))}</th><td><pre>{escape(str(value))}</pre></td></tr>")
    return ("<!doctype html><html><head><meta charset='utf-8'><title>UNMASK report</title>"
            "<style>body{font:14px Arial;margin:32px;color:#182230}table{border-collapse:collapse;width:100%}"
            "th,td{border:1px solid #ccd3dc;padding:10px;text-align:left;vertical-align:top}"
            "pre{white-space:pre-wrap;overflow-wrap:anywhere}</style></head><body>"
            f"<h1>UNMASK Security Reconnaissance Report</h1><h2>{escape(domain)}</h2>"
            f"<table>{''.join(rows)}</table></body></html>")

def make_pdf_report(domain, results):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=36, leftMargin=36)
    styles = getSampleStyleSheet()
    story = [Paragraph("UNMASK Security Reconnaissance Report", styles["Title"]),
             Paragraph(domain, styles["Heading2"]), Spacer(1, 12)]
    rows = [["Section", "Result"]]
    for key, value in results.items():
        rows.append([str(key), str(value)[:1800]])
    table = Table(rows, colWidths=[95, 400], repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#182230")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("GRID", (0,0), (-1,-1), 0.4, colors.grey),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("FONTSIZE", (0,0), (-1,-1), 7),
        ("WORDWRAP", (0,0), (-1,-1), True),
    ]))
    story.append(table)
    doc.build(story)
    return buffer.getvalue()
