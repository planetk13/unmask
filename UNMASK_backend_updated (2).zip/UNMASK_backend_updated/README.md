# UNMASK Backend — Updated Starter

A Flask API for authorized, DNS-verified website reconnaissance.

## Security model
- A user must explicitly confirm authorization before adding a target.
- A target cannot be scanned until its DNS TXT ownership token is verified.
- Scan routes are scoped to the authenticated user.
- Recon is passive/low-impact: DNS, WHOIS, TLS, HTTP security headers, and Certificate Transparency names.
- No port scanning, exploitation, credential testing, or active vulnerability probing is included.
- HTTP requests reject hostnames that resolve to non-public IP addresses.
- Passwords are hashed; sessions are HttpOnly; CSRF protection is enabled; login and scan routes are rate-limited.

Only add domains you own or are explicitly authorized to assess.

## Windows setup
Open CMD in this folder:

```cmd
py -3 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```

Edit `.env`:
1. Set `SECRET_KEY` to a long random secret.
2. Set `CORS_ORIGINS` to your exact frontend preview origin(s), comma-separated.
3. Keep `SESSION_COOKIE_SECURE=true` when using HTTPS frontend/tunnel.

Run:

```cmd
python app.py
```

Health check:

```cmd
curl http://127.0.0.1:5000/api/health
```

## Frontend API
Set `VITE_API_BASE_URL` to the public backend base URL (no trailing slash).
Frontend requests that use sessions must include `credentials: "include"` and obtain a CSRF token from `GET /api/csrf-token`; send it in `X-CSRFToken` on unsafe requests.

## Target verification
`POST /api/targets` body:
```json
{"domain":"example.com","authorized":true}
```
Publish the returned TXT record at `_unmask-verification.example.com`, then call:
`POST /api/targets/<id>/verify`.

The token is returned only to the authenticated owner who added the target.

## API endpoints
- `GET /api/health`
- `GET /api/csrf-token`
- `POST /api/register`
- `POST /api/login`
- `GET /api/me`
- `POST /api/logout`
- `GET /api/dashboard`
- `GET|POST /api/targets`
- `POST /api/targets/<id>/verify`
- `DELETE /api/targets/<id>`
- `GET|POST /api/scans`
- `GET /api/scans/<id>`
- `GET /api/scans/<id>/report/html`
- `GET /api/scans/<id>/report/pdf`

## Important
This is a newly assembled backend package based on the current UNMASK feature requirements. It is not a byte-for-byte copy of the previously tested working folder. Run the included checks and test it against a development database before replacing your current backend. Back up your existing database and source first.
