import os
from datetime import datetime, timezone
from io import BytesIO
from functools import wraps

from flask import Flask, jsonify, request, session, send_file, render_template_string
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_wtf.csrf import CSRFProtect, generate_csrf
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.exc import IntegrityError

from config import Config
from database import db, User, AuthorizedTarget, Scan
from modules.domain_verification import make_verification_token, verify_domain
from modules.recon import run_recon
from reports import make_html_report, make_pdf_report

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

allowed_origins = app.config["CORS_ORIGINS"]
CORS(app, resources={r"/api/*": {"origins": allowed_origins}},
     supports_credentials=True, allow_headers=["Content-Type", "X-CSRFToken"],
     methods=["GET", "POST", "DELETE", "OPTIONS"])

csrf = CSRFProtect(app)
limiter = Limiter(get_remote_address, app=app,
                  default_limits=[],
                  storage_uri=app.config.get("RATELIMIT_STORAGE_URI", "memory://"))

with app.app_context():
    db.create_all()


def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            return jsonify({"error": "Authentication required"}), 401
        return fn(*args, **kwargs)
    return wrapper


def json_body():
    return request.get_json(silent=True) or {}


@app.get("/")
def index():
    return jsonify({"name": "UNMASK API", "status": "running"})


@app.get("/api/health")
def health():
    return jsonify({"status": "success", "message": "UNMASK backend is running"})


@app.get("/api/csrf-token")
def csrf_token():
    return jsonify({"csrf_token": generate_csrf()})


@app.post("/api/register")
@limiter.limit("5 per minute")
def register():
    data = json_body()
    email = str(data.get("email", "")).strip().lower()
    password = data.get("password", "")
    if not email or "@" not in email or len(email) > 254:
        return jsonify({"error": "A valid email is required"}), 400
    if not isinstance(password, str) or len(password) < 10:
        return jsonify({"error": "Password must contain at least 10 characters"}), 400
    user = User(email=email, password_hash=generate_password_hash(password))
    db.session.add(user)
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return jsonify({"error": "An account with this email already exists"}), 409
    session.clear()
    session["user_id"] = user.id
    return jsonify({"message": "Account created", "user": user.public()}), 201


@app.post("/api/login")
@limiter.limit("5 per minute")
def login():
    data = json_body()
    email = str(data.get("email", "")).strip().lower()
    password = data.get("password", "")
    user = User.query.filter_by(email=email).first()
    if not user or not isinstance(password, str) or not check_password_hash(user.password_hash, password):
        return jsonify({"error": "Invalid email or password"}), 401
    session.clear()
    session["user_id"] = user.id
    return jsonify({"message": "Login successful", "user": user.public()})


@app.get("/api/me")
def me():
    user = current_user()
    if not user:
        return jsonify({"error": "Not logged in"}), 401
    return jsonify({"user": user.public()})


@app.post("/api/logout")
@login_required
def logout():
    session.clear()
    return jsonify({"message": "Logged out"})


@app.get("/api/dashboard")
@login_required
def dashboard():
    user = current_user()
    return jsonify({
        "user": user.public(),
        "total_targets": AuthorizedTarget.query.filter_by(user_id=user.id).count(),
        "verified_targets": AuthorizedTarget.query.filter_by(user_id=user.id, verified=True).count(),
        "total_scans": Scan.query.filter_by(user_id=user.id).count()
    })


@app.route("/api/targets", methods=["GET", "POST"])
def targets():
    user = current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401
    if request.method == "GET":
        items = AuthorizedTarget.query.filter_by(user_id=user.id).order_by(AuthorizedTarget.id.desc()).all()
        return jsonify({"total_targets": len(items), "targets": [t.public(include_token=True) for t in items]})

    data = json_body()
    domain = str(data.get("domain", "")).strip().lower().rstrip(".")
    authorized = data.get("authorized") is True
    if not authorized:
        return jsonify({"error": "Explicit authorization confirmation is required"}), 400
    if not domain or len(domain) > 253 or "://" in domain or "/" in domain or "@" in domain:
        return jsonify({"error": "Enter a domain name only, without a URL path"}), 400
    import re
    if not re.fullmatch(r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}", domain):
        return jsonify({"error": "Invalid public domain name"}), 400
    if AuthorizedTarget.query.filter_by(user_id=user.id, domain=domain).first():
        return jsonify({"error": "Target already exists"}), 409
    token = make_verification_token()
    target = AuthorizedTarget(user_id=user.id, domain=domain, verification_token=token,
                              authorization_status="user_confirmed", verified=False)
    db.session.add(target)
    db.session.commit()
    return jsonify({
        "message": "Target added. Publish the DNS TXT record to verify ownership.",
        "target": target.public(include_token=True),
        "dns_instructions": {"record_type": "TXT", "host": "@", "value": token}
    }), 201


@app.post("/api/targets/<int:target_id>/verify")
@login_required
def verify_target(target_id):
    user = current_user()
    target = AuthorizedTarget.query.filter_by(id=target_id, user_id=user.id).first()
    if not target:
        return jsonify({"error": "Target not found"}), 404
    if target.verified:
        return jsonify({"message": "Target already verified", "verified": True})
    ok, detail = verify_domain(target.domain, target.verification_token)
    if ok:
        target.verified = True
        target.verified_at = datetime.now(timezone.utc)
        db.session.commit()
    return jsonify({"verified": ok, "message": detail}), (200 if ok else 400)


@app.delete("/api/targets/<int:target_id>")
@login_required
def delete_target(target_id):
    user = current_user()
    target = AuthorizedTarget.query.filter_by(id=target_id, user_id=user.id).first()
    if not target:
        return jsonify({"error": "Target not found"}), 404
    db.session.delete(target)
    db.session.commit()
    return jsonify({"message": "Target deleted"})


@app.get("/api/scans")
@login_required
def scan_history():
    user = current_user()
    scans = Scan.query.filter_by(user_id=user.id).order_by(Scan.id.desc()).all()
    return jsonify({"scans": [s.public() for s in scans]})


@app.post("/api/scans")
@limiter.limit("10 per hour")
@login_required
def create_scan():
    user = current_user()
    data = json_body()
    try:
        target_id = int(data.get("target_id"))
    except (TypeError, ValueError):
        return jsonify({"error": "A valid target_id is required"}), 400
    target = AuthorizedTarget.query.filter_by(id=target_id, user_id=user.id).first()
    if not target:
        return jsonify({"error": "Target not found"}), 404
    if target.verified is not True:
        return jsonify({"error": "DNS ownership verification is required before scanning"}), 403

    result = run_recon(target.domain)
    scan = Scan(user_id=user.id, target_id=target.id, domain=target.domain,
                status="completed", results=result)
    db.session.add(scan)
    db.session.commit()
    return jsonify({"message": "Reconnaissance completed", "scan": scan.public()}), 201


@app.get("/api/scans/<int:scan_id>")
@login_required
def get_scan(scan_id):
    user = current_user()
    scan = Scan.query.filter_by(id=scan_id, user_id=user.id).first()
    if not scan:
        return jsonify({"error": "Scan not found"}), 404
    return jsonify({"scan": scan.public(include_results=True)})


@app.get("/api/scans/<int:scan_id>/report/html")
@login_required
def html_report(scan_id):
    user = current_user()
    scan = Scan.query.filter_by(id=scan_id, user_id=user.id).first()
    if not scan:
        return jsonify({"error": "Scan not found"}), 404
    return make_html_report(scan.domain, scan.results)


@app.get("/api/scans/<int:scan_id>/report/pdf")
@login_required
def pdf_report(scan_id):
    user = current_user()
    scan = Scan.query.filter_by(id=scan_id, user_id=user.id).first()
    if not scan:
        return jsonify({"error": "Scan not found"}), 404
    payload = make_pdf_report(scan.domain, scan.results)
    return send_file(BytesIO(payload), mimetype="application/pdf",
                     as_attachment=True, download_name=f"UNMASK-{scan.domain}.pdf")


@app.errorhandler(400)
def bad_request(_):
    return jsonify({"error": "Bad request"}), 400


@app.errorhandler(404)
def not_found(_):
    return jsonify({"error": "Endpoint not found"}), 404


@app.errorhandler(429)
def too_many(_):
    return jsonify({"error": "Rate limit exceeded"}), 429


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=False)
