from datetime import datetime, timezone
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def utcnow():
    return datetime.now(timezone.utc)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(254), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), default=utcnow, nullable=False)
    def public(self):
        return {"id": self.id, "email": self.email}

class AuthorizedTarget(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)
    domain = db.Column(db.String(253), nullable=False)
    authorization_status = db.Column(db.String(40), default="user_confirmed", nullable=False)
    verification_token = db.Column(db.String(128), nullable=False)
    verified = db.Column(db.Boolean, default=False, nullable=False)
    verified_at = db.Column(db.DateTime(timezone=True))
    created_at = db.Column(db.DateTime(timezone=True), default=utcnow, nullable=False)
    __table_args__ = (db.UniqueConstraint("user_id", "domain", name="uq_user_target_domain"),)
    def public(self, include_token=False):
        item = {"id": self.id, "domain": self.domain,
                "authorization_status": self.authorization_status,
                "verified": self.verified, "created_at": self.created_at.isoformat()}
        if include_token and not self.verified:
            item["verification_token"] = self.verification_token
            item["dns_instructions"] = {"record_type": "TXT",
                "host": "@", "value": self.verification_token}
        return item

class Scan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="CASCADE"), nullable=False, index=True)
    target_id = db.Column(db.Integer, db.ForeignKey("authorized_target.id", ondelete="CASCADE"), nullable=False)
    domain = db.Column(db.String(253), nullable=False)
    status = db.Column(db.String(30), default="completed", nullable=False)
    results = db.Column(db.JSON, nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), default=utcnow, nullable=False)
    def public(self, include_results=False):
        data = {"id": self.id, "target_id": self.target_id, "domain": self.domain,
                "status": self.status, "created_at": self.created_at.isoformat()}
        if include_results:
            data["results"] = self.results
        return data
